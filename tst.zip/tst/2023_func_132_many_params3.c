int func(int aa, int ab, int ac, int ad, int ae, int af, int ag, int ah, int ai, int aj, int ak, int al, int am, int an, int ao, int ap, int aq, int ar, int as, int at, int au, int av, int aw, int ax, int ay, int az, 
int ba, int bb, int bc, int bd, int be, int bf, int bg, int bh, int bi, int bj, int bk, int bl, int bm, int bn, int bo, int bp, int bq, int br, int bs, int bt, int bu, int bv, int bw, int bx, int by, int bz, 
int ca, int cb, int cc, int cd, int ce, int cf, int cg, int ch, int ci, int cj, int ck, int cl, int cm, int cn, int co, int cp, int cq, int cr, int cs, int ct, int cu, int cv, int cw, int cx, int cy, int cz, 
int da, int db, int dc, int dd, int de, int df, int dg, int dh, int di, int dj, int dk, int dl, int dm, int dn, int doo, int dp, int dq, int dr, int ds, int dt, int du, int dv, int dw, int dx, int dy, int dz, 
int ea, int eb, int ec, int ed, int ee, int ef, int eg, int eh, int ei, int ej, int ek, int el, int em, int en, int eo, int ep, int eq, int er, int es, int et, int eu, int ev, int ew, int ex, int ey, int ez, 
int fa, int fb, int fc, int fd, int fe, int ff, int fg, int fh, int fi, int fj, int fk, int fl, int fm, int fn, int fo, int fp, int fq, int fr, int fs, int ft, int fu, int fv, int fw, int fx, int fy, int fz, 
int ga, int gb, int gc, int gd, int ge, int gf, int gg, int gh, int gi, int gj, int gk, int gl, int gm, int gn, int go, int gp, int gq, int gr, int gs, int gt, int gu, int gv, int gw, int gx, int gy, int gz, 
int ha, int hb, int hc, int hd, int he, int hf, int hg, int hh, int hi, int hj, int hk, int hl, int hm, int hn, int ho, int hp, int hq, int hr, int hs, int ht, int hu, int hv, int hw, int hx, int hy, int hz, 
int ia, int ib, int ic, int id, int ie, int iff, int ig, int ih, int ii, int ij, int ik, int il, int im, int in, int io, int ip, int iq, int ir, int is, int it, int iu, int iv, int iw, int ix, int iy, int iz, 
int ja, int jb, int jc, int jd, int je, int jf, int jg, int jh, int ji, int jj, int jk, int jl, int jm, int jn, int jo, int jp, int jq, int jr, int js, int jt, int ju, int jv, int jw, int jx, int jy, int jz, 
int ka, int kb, int kc, int kd, int ke, int kf, int kg, int kh, int ki, int kj, int kk, int kl, int km, int kn, int ko, int kp, int kq, int kr, int ks, int kt, int ku, int kv, int kw, int kx, int ky, int kz, 
int la, int lb, int lc, int ld, int le, int lf, int lg, int lh, int li, int lj, int lk, int ll, int lm, int ln, int lo, int lp, int lq, int lr, int ls, int lt, int lu, int lv, int lw, int lx, int ly, int lz, 
int ma, int mb, int mc, int md, int me, int mf, int mg, int mh, int mi, int mj, int mk, int ml, int mm, int mn, int mo, int mp, int mq, int mr, int ms, int mt, int mu, int mv, int mw, int mx, int my, int mz, 
int na, int nb, int nc, int nd, int ne, int nf, int ng, int nh, int ni, int nj, int nk, int nl, int nm, int nn, int no, int np, int nq, int nr, int ns, int nt, int nu, int nv, int nw, int nx, int ny, int nz, 
int oa, int ob, int oc, int od, int oe, int of, int og, int oh, int oi, int oj, int ok, int ol, int om, int on, int oo, int op, int oq, int or, int os, int ot, int ou, int ov, int ow, int ox, int oy, int oz, 
int pa, int pb, int pc, int pd, int pe, int pf, int pg, int ph, int pi, int pj, int pk, int pl, int pm, int pn, int po, int pp, int pq, int pr, int ps, int pt, int pu, int pv, int pw, int px, int py, int pz, 
int qa, int qb, int qc, int qd, int qe, int qf, int qg, int qh, int qi, int qj, int qk, int ql, int qm, int qn, int qo, int qp, int qq, int qr, int qs, int qt, int qu, int qv, int qw, int qx, int qy, int qz, 
int ra, int rb, int rc, int rd, int re, int rf, int rg, int rh, int ri, int rj, int rk, int rl, int rm, int rn, int ro, int rp, int rq, int rr, int rs, int rt, int ru, int rv, int rw, int rx, int ry, int rz, 
int sa, int sb, int sc, int sd, int se, int sf, int sg, int sh, int si, int sj, int sk, int sl, int sm, int sn, int so, int sp, int sq, int sr, int ss, int st, int su, int sv, int sw, int sx, int sy, int sz, 
int ta, int tb, int tc, int td, int te, int tf, int tg, int th, int ti, int tj, int tk, int tl, int tm, int tn, int to, int tp, int tq, int tr, int ts, int tt, int tu, int tv, int tw, int tx, int ty, int tz, 
int ua, int ub, int uc, int ud, int ue, int uf, int ug, int uh, int ui, int uj, int uk, int ul, int um, int un, int uo, int up, int uq, int ur, int us, int ut, int uu, int uv, int uw, int ux, int uy, int uz, 
int va, int vb, int vc, int vd, int ve, int vf, int vg, int vh, int vi, int vj, int vk, int vl, int vm, int vn, int vo, int vp, int vq, int vr, int vs, int vt, int vu, int vv, int vw, int vx, int vy, int vz, 
int wa, int wb, int wc, int wd, int we, int wf, int wg, int wh, int wi, int wj, int wk, int wl, int wm, int wn, int wo, int wp, int wq, int wr, int ws, int wt, int wu, int wv, int ww, int wx, int wy, int wz, 
int xa, int xb, int xc, int xd, int xe, int xf, int xg, int xh, int xi, int xj, int xk, int xl, int xm, int xn, int xo, int xp, int xq, int xr, int xs, int xt, int xu, int xv, int xw, int xx, int xy, int xz, 
int ya, int yb, int yc, int yd, int ye, int yf, int yg, int yh, int yi, int yj, int yk, int yl, int ym, int yn, int yo, int yp, int yq, int yr, int ys, int yt, int yu, int yv, int yw, int yx, int yy, int yz, 
int za, int zb, int zc, int zd, int ze, int zf, int zg, int zh, int zi, int zj, int zk, int zl, int zm, int zn, int zo, int zp, int zq, int zr, int zs, int zt, int zu, int zv, int zw, int zx, int zy, int zz){
	return 
	zi*xy*ve*zl*dk+ui+sd*bx*qr*kk*qk*jt*xj+wl*wg+kb+ii*vj*oa+pb*
	ku+ee*fv+ha+bm*jv*ka*mr+gv+qh+ci+az*lj*ie+pz*zg+js*wj*il*fx*
	vs+ed+te+ke+sq*hq*da+vb*gp+ab*kx*lc+pn*ae+cs*on+xe+zi+mf+sc*
	ak*ko+hx*ax+gc*cm+br*fl+ul+el+nt+tt*eh+gq+up*uj*kz+yj+ah*dl*
	xz*il*km*qp*yx+lc+re*qb+nl+on+gq+zs+ca*lh+ra+doo*op+cl*et*ad+
	kb+tc+bb*oo+mg+ws*xj+ri*ty*mu+cy+dp*wm*wt+dw+pv+it+iy+it+za*
	hw+kx*pc*zs*ht*sv*jy+gk+cq*ym*vz*de*gg+fc*dk*yb*wm+zu+th*bn*
	iy*doo+al+vj*ex*di*jb*ss*bd*kn+yz+kw+tv*ug+iff*wx*fn*ul*tt*fp*
	hn*dv*zv*al*wr+fa*vv+ls+ia*ip*uv+li+zs+em+pa*zf+zb+bt+ad+jp+
	ut+tm+et+ct+hc+en*hd*hf*cr*lm+pp*wj*nd*ka*ta+ru*jn+en+gc*jb+
	kg*bf+sl+pr+uc+yv+vd*td*xg+cp*rj+qu+vw*ao*oz+zf+qj+kl*st*on*
	qq+mv*eu*ay*ih*ta*tm+vh+rz+yn*bp+pr+xt*lw+uo*zl*rv+fz*rz*fz+
	mf*sj+xz*yt+qj+ki*gf+ne+gd+vz+oh+hh+ff+ec*xk+hb+pe+mz*yx*aw+
	ij+dn+zj*nm+jj*kz*ic*sg+ue*yo+le+fg*kt*br*yx+so*qy+bd+da+iq+
	go+uu+jj*le+xa+vs*qs+mq+vr+ua+hx*oz*sl*cj*hg+rd*bz+vk*ic+ib+
	fj*au*dm+ve*ks+pl*oi*kd*iu+be*rr+va*hc*tl+wm+rq+ob+pg*hq+pe*
	ww*ei*rn+yk+oc*sh*ig*uu+cg*vu*yn+xj*wh+xf+wo+nr+vf*sa*yg+uj+
	sb+dt+pn+ui+nc*bv+qa*ze*kn+zt*da+kw*xp+hy*hs+pb+ox*uz*pe+be*
	im+sg+tm*im+gh*ju*zx+fc+pn*ei*we+ae*re+wp*aj+pc*km*pm+hc*bt*
	ap*ik*am+yu+my+wh*ah*tt*fo+rx*te*al+tq+fj+df*ts+jl+lx+ov+in;
}

int main(){
	return func(
	0,1,1,8,9,5,2,0,6,2,4,7,1,6,9,3,3,5,0,8,9,3,4,5,9,0,
	8,9,5,5,4,1,4,3,5,9,7,6,1,7,5,4,0,7,5,5,6,4,9,6,6,6,
	8,0,4,2,3,3,0,5,4,3,9,5,9,3,3,6,4,3,3,0,5,0,2,5,6,6,
	9,4,0,3,7,2,1,1,9,8,4,8,5,2,5,4,5,0,3,5,0,7,0,7,5,6,
	7,7,8,2,6,8,9,4,6,7,2,9,8,8,0,0,3,4,8,9,0,5,9,8,5,1,
	2,7,3,2,5,4,9,9,6,9,2,5,5,7,8,3,8,9,4,9,0,5,9,8,4,2,
	5,0,7,8,8,4,6,7,9,8,2,4,4,2,9,9,8,1,2,3,7,2,2,1,7,1,
	2,4,0,6,6,0,9,9,0,7,8,9,8,5,1,8,9,2,4,7,3,4,7,9,9,4,
	7,1,9,0,6,0,6,9,8,4,3,6,2,9,7,5,6,9,8,6,5,8,4,0,5,2,
	3,2,4,0,0,9,5,8,9,2,5,2,5,0,9,4,2,0,0,1,5,0,4,9,4,9,
	4,6,0,0,4,2,6,9,3,7,8,5,5,7,1,0,5,3,6,0,3,3,6,2,9,9,
	1,9,6,2,4,1,5,1,5,0,8,5,7,9,4,6,1,3,9,4,2,3,0,8,6,0,
	9,7,3,1,3,7,0,9,2,3,1,2,9,3,8,5,7,3,9,6,7,1,9,6,3,8,
	1,8,8,2,8,7,5,4,2,0,4,0,7,7,8,9,6,6,7,7,1,6,0,5,3,4,
	2,6,3,6,3,4,1,3,6,9,4,3,0,9,0,2,2,0,8,8,4,5,8,2,3,3,
	7,2,5,9,6,7,0,1,8,5,7,8,3,0,2,9,1,5,4,9,4,5,3,7,4,0,
	2,7,1,3,2,7,1,7,0,0,6,7,8,9,0,2,5,4,6,2,9,2,1,0,2,2,
	7,3,8,9,6,3,6,9,0,8,1,2,2,9,5,8,2,5,0,4,7,0,8,2,9,6,
	7,7,5,2,6,6,8,8,9,7,7,4,9,0,8,7,6,8,3,1,6,7,4,6,5,6,
	2,8,8,5,9,0,3,1,9,1,4,9,6,4,7,6,6,8,9,6,6,1,2,5,2,0,
	3,8,2,9,1,3,9,6,2,3,2,9,9,3,8,8,1,9,8,5,1,1,2,7,9,3,
	7,4,3,4,0,7,4,9,1,4,6,4,3,8,3,8,7,6,3,2,1,8,5,2,3,1,
	3,7,6,2,4,0,9,9,7,8,3,7,5,8,8,5,6,7,3,2,9,5,5,1,5,7,
	9,7,9,0,5,4,3,3,0,0,0,3,5,1,6,2,0,4,7,4,9,7,3,4,0,6,
	0,3,1,3,5,7,3,8,3,1,9,6,8,6,7,7,3,2,9,8,1,9,5,8,4,7,
	8,9,9,0,9,2,9,0,0,7,4,3,9,2,2,7,8,7,1,3,5,8,4,4,0,9);
}


