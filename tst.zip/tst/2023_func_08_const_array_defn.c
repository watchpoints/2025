const int a[5]={0,1,2,3,4};

int main(){
    return a[4];
}