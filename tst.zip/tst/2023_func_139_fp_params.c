int k;

float params_f40(float x0, float x1, float x2, float x3, float x4, float x5,
                 float x6, float x7, float x8, float x9, float x10, float x11,
                 float x12, float x13, float x14, float x15, float x16,
                 float x17, float x18, float x19, float x20, float x21,
                 float x22, float x23, float x24, float x25, float x26,
                 float x27, float x28, float x29, float x30, float x31,
                 float x32, float x33, float x34, float x35, float x36,
                 float x37, float x38, float x39) {
  if (x39 != 0) {
    float arr[10] = {x0 + x1 + x2 + x3,     x4 + x5 + x6 + x7,
                     x8 + x9 + x10 + x11,   x12 + x13 + x14 + x15,
                     x16 + x17 + x18 + x19, x20 + x21 + x22 + x23,
                     x24 + x25 + x26 + x27, x28 + x29 + x30 + x31,
                     x32 + x33 + x34 + x35, x36 + x37 + x38 + x39};
    putfarray(10, arr);
    return arr[k];
  } else {
    return params_f40(x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13,
                      x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24,
                      x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35,
                      x36, x37, x38, x39, x0 + x1 + x2);
  }
}

float params_f40_i24(int i23, int i2, int i6, float x4, int i1, int i4, int i5,
                     float x8, float x15, float x7, int i22, float x3,
                     float x28, int i0, float x37, int i19, float x30,
                     float x12, float x1, float x11, float x38, float x6,
                     int i7, float x32, int i10, int i13, float x20, float x33,
                     float x23, float x9, float x25, int i8, float x39, int i17,
                     float x21, float x16, float x5, float x34, int i18, int i9,
                     float x14, float x10, float x0, int i12, float x31,
                     int i11, int i16, float x27, float x24, float x13,
                     float x29, int i3, int i21, int i20, float x18, float x19,
                     float x22, float x26, float x36, float x17, int i15,
                     float x2, int i14, float x35) {
  if (i23 != 0) {
    float arr[10] = {x0 + x1 + x2 + x3,     x4 + x5 + x6 + x7,
                     x8 + x9 + x10 + x11,   x12 + x13 + x14 + x15,
                     x16 + x17 + x18 + x19, x20 + x21 + x22 + x23,
                     x24 + x25 + x26 + x27, x28 + x29 + x30 + x31,
                     x32 + x33 + x34 + x35, x36 + x37 + x38 + x39};
    int arr2[8] = {i0 + i1 + i2,    i3 + i4 + i5,    i6 + i7 + i8,
                   i9 + i10 + i11,  i12 + i13 + i14, i15 + i16 + i17,
                   i18 + i19 + i20, i21 + i22 + i23};
    putfarray(10, arr);
    putarray(8, arr2);
    int i = 0;
    while (i < 8) {
      arr2[i] = arr2[i] - arr[i];
      i = i + 1;
    }
    return arr2[k];
  } else {
    return params_f40_i24(i1, i2, i6, x4, i1, i4, i5, x8, x15, x7, i22, x3, x28,
                          i0, x37, i19, x30, x12, x1, x11, x38, x6, i7, x32,
                          i10, i13, x20, x33, x23, x9, x25, i8, x39, i17, x21,
                          x16, x5, x34, i18, i9, x14, x10, x0, i12, x31, i11,
                          i16, x27, x24, x13, x29, i3, i21, i20, x18, x19, x22,
                          x26, x36, x17, i15, x2, i14, x35);
  }
}

float params_fa40(float x0[], float x1[], float x2[], float x3[], float x4[],
                  float x5[], float x6[], float x7[], float x8[], float x9[],
                  float x10[], float x11[], float x12[], float x13[],
                  float x14[], float x15[], float x16[], float x17[],
                  float x18[], float x19[], float x20[], float x21[],
                  float x22[], float x23[], float x24[], float x25[],
                  float x26[], float x27[], float x28[], float x29[],
                  float x30[], float x31[], float x32[], float x33[],
                  float x34[], float x35[], float x36[], float x37[],
                  float x38[], float x39[]) {
  float arr[10] = {
      x0[k] + x1[k] + x2[k] + x3[k],     x4[k] + x5[k] + x6[k] + x7[k],
      x8[k] + x9[k] + x10[k] + x11[k],   x12[k] + x13[k] + x14[k] + x15[k],
      x16[k] + x17[k] + x18[k] + x19[k], x20[k] + x21[k] + x22[k] + x23[k],
      x24[k] + x25[k] + x26[k] + x27[k], x28[k] + x29[k] + x30[k] + x31[k],
      x32[k] + x33[k] + x34[k] + x35[k], x36[k] + x37[k] + x38[k] + x39[k]};
  if (x39[k] != 0 != 0 != .0 != 0.) {
    putfarray(10, arr);
    return arr[k];
  } else {
    return params_fa40(x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13,
                       x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24,
                       x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35,
                       x36, x37, x38, x39, arr);
  }
}

int params_mix(float x0, int i1[], int i2, float x3[], float x4, int i5,
               float x6, float x7, float x8[], int i9[], int i10, int i11,
               float x12[], int i13[], int i14[], int i15, float x16[],
               float x17[], float x18, float x19, float x20, float x21[],
               int i22, float x23, float x24, float x25, int i26[], float x27[],
               int i28[], int i29[], float x30[], float x31, float x32,
               int i33[], int i34, float x35[], float x36[], float x37,
               float x38, int i39[], int i40[], int i41, int i42, float x43,
               float x44, int i45[], int i46, float x47[], int i48, int i49[],
               int i50[], float x51, float x52, float x53[], int i54, int i55[],
               float x56[], float x57, int i58, float x59, float x60[],
               float x61[], float x62, int i63) {
  float arr[10] = {x0 + x3[k] + x4 + x6,        x7 + x8[k] + x12[k] + x16[k],
                   x17[k] + x18 + x19 + x20,    x21[k] + x23 + x24 + x25,
                   x27[k] + x30[k] + x31 + x32, x35[k] + x36[k] + x37 + x38,
                   x43 + x44 + x47[k] + x51,    x52 + x53[k] + x56[k] + x57,
                   x59 + x60[k] + x61[k] + x62};
  int arr2[10] = {
      i1[k] + i2 + i5,       i9[k] + i10 + i11,     i13[k] + i14[k] + i15,
      i22 + i26[k] + i28[k], i29[k] + i33[k] + i34, i39[k] + i40[k] + i41,
      i42 + i45[k] + i46,    i48 + i49[k] + i50[k], i54 + i55[k] + i58 + i63};
  if (i63 != 0) {
    putfarray(10, arr);
    putarray(10, arr2);
    int i = 0;
    while (i < 10) {
      arr2[i] = arr2[i] - arr[i];
      i = i + 1;
    }
    return arr2[k] * arr[8];
  } else {
    return params_mix(x0, arr2, i2, arr, x4, i5, x6, x7, x8, i9, i10, i11, x12,
                      i13, i14, i15, x16, x17, x18, x19, x20, x21, i22, x23,
                      x24, x25, i26, x27, i28, i29, x30, x31, x32, i33, i34,
                      x35, x36, x37, x38, i39, i40, i41, i42, x43, x44, i45,
                      i46, x47, i48, i49, i50, x51, x52, x53, i54, i55, x56,
                      x57, i58, x59, x60, x61, i63, x62);
  }
}

int main() {
  float arr[40][3];
  int arr2[24][3], i;

  k = getint();
  i = 0;
  while (i < 40) {
    getfarray(arr[i]);
    i = i + 1;
  }
  i = 0;
  while (i < 24) {
    getarray(arr2[i]);
    i = i + 1;
  }

  float ret0 = params_f40(
      arr[0][k], arr[1][k], arr[2][k], arr[3][k], arr[4][k], arr[5][k],
      arr[6][k], arr[7][k], arr[8][k], arr[9][k], arr[10][k], arr[11][k],
      arr[12][k], arr[13][k], arr[14][k], arr[15][k], arr[16][k], arr[17][k],
      arr[18][k], arr[19][k], arr[20][k], arr[21][k], arr[22][k], arr[23][k],
      arr[24][k], arr[25][k], arr[26][k], arr[27][k], arr[28][k], arr[29][k],
      arr[30][k], arr[31][k], arr[32][k], arr[33][k], arr[34][k], arr[35][k],
      arr[36][k], arr[37][k], arr[38][k], arr[39][k]);
  float ret1 = params_f40_i24(
      arr2[23][k], arr2[2][k], arr2[6][k], arr[4][k], arr2[1][k], arr2[4][k],
      arr2[5][k], arr[8][k], arr[15][k], arr[7][k], arr2[22][k], arr[3][k],
      arr[28][k], arr2[0][k], arr[37][k], arr2[19][k], arr[30][k], arr[12][k],
      arr[1][k], arr[11][k], arr[38][k], arr[6][k], arr2[7][k], arr[32][k],
      arr2[10][k], arr2[13][k], arr[20][k], arr[33][k], arr[23][k], arr[9][k],
      arr[25][k], arr2[8][k], arr[39][k], arr2[17][k], arr[21][k], arr[16][k],
      arr[5][k], arr[34][k], arr2[18][k], arr2[9][k], arr[14][k], arr[10][k],
      arr[0][k], arr2[12][k], arr[31][k], arr2[11][k], arr2[16][k], arr[27][k],
      arr[24][k], arr[13][k], arr[29][k], arr2[3][k], arr2[21][k], arr2[20][k],
      arr[18][k], arr[19][k], arr[22][k], arr[26][k], arr[36][k], arr[17][k],
      arr2[15][k], arr[2][k], arr2[14][k], arr[35][k]);
  float ret2 = params_fa40(
      arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], arr[8],
      arr[9], arr[10], arr[11], arr[12], arr[13], arr[14], arr[15], arr[16],
      arr[17], arr[18], arr[19], arr[20], arr[21], arr[22], arr[23], arr[24],
      arr[25], arr[26], arr[27], arr[28], arr[29], arr[30], arr[31], arr[32],
      arr[33], arr[34], arr[35], arr[36], arr[37], arr[38], arr[39]);
  int ret3 = params_mix(
      arr[0][k], arr2[0], arr2[1][k], arr[1], arr[2][k], arr2[2][k], arr[3][k],
      arr[4][k], arr[5], arr2[3], arr2[4][k], arr2[5][k], arr[6], arr2[6],
      arr2[7], arr2[8][k], arr[7], arr[8], arr[9][k], arr[10][k], arr[11][k],
      arr[12], arr2[9][k], arr[13][k], arr[14][k], arr[15][k], arr2[10],
      arr[16], arr2[11], arr2[12], arr[17], arr[18][k], arr[19][k], arr2[13],
      arr2[14][k], arr[20], arr[21], arr[22][k], arr[23][k], arr2[15], arr2[16],
      arr2[17][k], arr2[18][k], arr[24][k], arr[25][k], arr2[19], arr2[20][k],
      arr[26], arr2[21][k], arr2[22], arr2[23], arr[27][k], arr[28][k], arr[29],
      arr2[0][k], arr2[1], arr[30], arr[31][k], arr2[2][k], arr[32][k], arr[33],
      arr[34], arr[35][k], arr2[3][k]);

  putfloat(ret0);
  putch(10);
  putfloat(ret1);
  putch(10);
  putfloat(ret2);
  putch(10);
  putint(ret3);
  putch(10);
  return 0;
}
