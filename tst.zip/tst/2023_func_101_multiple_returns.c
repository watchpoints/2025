int main() {
  int a, b = 8, c = 12;
  a = b + c;
  return a;
  int d = 9;
  a = a * d;
  return a;
  const int A = 4;
  a = (A - b) * c;
  return a;
  return a;
}