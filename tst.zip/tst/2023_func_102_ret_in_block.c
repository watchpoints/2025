int main(){
	int a = 893;
	int b = 716;
	{
		int a = 837;
		a = a + 128;
		b = b + a;
		{
			int b = 241;
			a = a + b - 412;
			{
				int a = 771;
				b = b + a -18;
				a = b + 66;
			}
			b = b + a - 33;
			a = b - 55;
            {
                return (a + b) % 21;
            }
            
		}
		a = b + a - 97;
		b = (b - a) % 62;
        {
             return (a + b) % 17;
        }
        return (a + b) % 13;
	}
	a = (b * a) % 83;
	b = a + b - 771;	
	return (a + b) % 11;
}




















