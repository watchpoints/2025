int f(int f) {
  return f * 2;
}

int main() {
  return f(10);
}
