int k;

int main() {
  k = 3389;
  if (k < 10000) {
    k = k + 1;
    int k = 112;
    while (k > 10) {
      k = k - 88;
      if (k < 1000) {
        int g = 9;
        {
          int l = 11;
          {
            g = 10;
            k = k - g;
            int g = 11;
            k = k + g + l;
          }
        }
      }
    }
    putint(k);
  }
  return k;
}
