//test addc
const int a = 10;
int main(){
    return a + 5;
}