const int N = 100;
const int M = 20;
int array[M][N];

int main() {
  int i = 0, sum = 0;
  while (i < M) {
    int j = 0;
    while (j < N) {
      array[i][j] = j;
      j = j + 1;
    }
    i = i + 1;
  }
  sum = 
  array[0][array[1][array[2][array[3][array[4][array[5][array[6][array[7][array[8][
    array[9][array[10][array[11][array[12][array[13][array[14][array[15][array[16][
      array[17][array[18][array[19][23]]]
    ]]]]]]]]
  ]]]]]]]]]
  + 
  array[array[array[array[array[array[array[array[array[array[array[array[array
  [array[array[array[array[array[array[array[19][18]]
  [17]][16]][15]][14]][13]][12]][11]][10]][9]][8]][7]]
  [6]][5]][4]][3]][2]][1]][0]][56];
  putint(sum);
  return 0;
}