//test the priority of  unary operator and binary operator
int main(){
    int a, b;
    a = 10;
    b = 30;
    return a - -5 + b + -5;
}