int main() {
    int a, b;
    a = 070;
    b = 0x4;
    a = a - - 4 + + b;
    if (+-!!!a) {
        a = - - -1;
    }
    else {
        a = 0 + + b;
    }
    putint(a);
    return 0;
}