//test add of hex and oct
int main(){
    int a, b;
    a = 0xf;
    b = 0xc;
    return a + b + 075;
}