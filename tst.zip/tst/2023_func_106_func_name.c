int f() {
  return 10;
}

int main() {
  int f = 20;
  return f;
}
