int main() {
  int sum = 0;
  int i = 0;
  while(i < 20) {
    int j = 0;
    while (j < 10) {
      int k = 0;
      while (k < 5) {
        int m = 0;
        while (m < 3) {
          if (m + 1 >= 3)
            if (m)
              if (m || !m)
                if (m - -1 >= 3)
                  {{{{;;break;continue;}}}}
          int n = 0;
          while (n < 2) {
            n = n + 1;
            continue;
            break;
            sum = sum + 1;
          }
          m = m + 1;
          sum = sum + 1;
        }
        while(1) {        
          while(1) break;
          break;
        }
        k = k + 1;
      }
      j = j + 1;
      continue;
      j = j + 1;
    }
    i = i + 1;
  }
  return sum;
}