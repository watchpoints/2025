int __HELLO [

	
100
		]	
= {
87, 101, 108, 99,
111, 109, 101,	 
32, 116, 111,	32,
116,	 104,
101, 32, 	74,
97,
	
112, 97,
 
	114, 	105,	32,	80, 97,	
	
	


114, 107,	 33, 10 }; /* Names of	
kemono
friends */ int	N4__mE___[6][50]		= { { 83, 97,	97, 98,
97, 
114,
117  }, 	{	75, 97, 98,	

97,  110
 
}, { 
 

72,

	  97,
115, 104, 105,
98, 105, 114, 111,

	

	
		

107,
	 111,
 

117

}, { 65, 114,

97, 

105,
103,	

117,
109, 


			97 },	
	{ 72, 117,
110, 98, 111, 114,
117,

116, 111,	  32, 80,
101, 110,
 
	103, 105, 	110
},
  {	84, 97, 105, 114, 105, 107, 117, 32, 79,
	
	 
111, 107,
97, 
109,
	
	
 
	 


 105	} };
	int

saY_HeI10_To[40] = { 32,
115, 97,  121,  
	
		115,

32,
104,

 101, 108, 108,	111, 

 32,
 
	
116, 111, 
32 };	int
		RET[5]
=
{10}; int putstr(  
int str[	] )  { 
  int

 iNd__1X ;	iNd__1X		= 0 ; while ( str
		[	iNd__1X
	] ) { 
	
 putch (

str[ iNd__1X 
]  
	) ; iNd__1X
=
iNd__1X
 	
 + 1 	

;	} return	iNd__1X
 ; } int main( /* no param */ )	{
putstr(
__HELLO	)  ;	int i =	
 0 ; /* say

 
	hello to
 kemono friends 
~ */ while (  
 
 1 ) {

int _  
 = i
 
/ 6
	
; int __
= 	
i % 6

;
     
	if 
( 

_ 

!=


	__ )
	{ putstr(

N4__mE___

	[ 	_	
 ] ) 
; putstr(	
saY_HeI10_To	) ;
putstr(
N4__mE___ [ 
		
 

__ ]	 )

	
;

		putstr(	
RET
) ;
}
/*
	 do
	
	linear
modulo 
to find 	the 	 next pair of friends  */ i = ( i
*
 	

17

+	 23
)
%


32	 

 
 ;
if ( i	
==
	0	) { break ;		}

 
 } return 0; }
