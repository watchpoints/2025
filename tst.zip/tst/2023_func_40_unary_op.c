int main() {
    int a;
    a = 10;
    if (+-!!!a) {
        a = - - -1;
    }
    else {
        a = 0;
    }
    return a;
}