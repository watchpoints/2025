int main() {
	int a=0;
	int i = 0;
	while (i < 3) {
		int j = 0;
		while (j < 4) {
			int k = 0;
			while (k < 5) {
				int ii = 0;
				while (ii < 3) {
					int jj = 0;
					while (jj < 5) {
						int kk = 0;
						while (kk < 4) {
							int iii = 0;
							while (iii < 6) {
								int jjj = 0;
								while (jjj < 5) {
									int kkk = 0;
									while (kkk < 5) {
										int iiii = 0;
										while (iiii < 3) {
											int jjjj = 0;
											while (jjjj < 6) {
												int kkkk = 0;
												while (kkkk < 7) {
													int iiiii = 0;
													while (iiiii < 5) {
														int jjjjj = 0;
														while (jjjjj < 3) {
															int kkkkk = 0;
															while (kkkkk < 6) {																
																a = (a + 3) % 999;																		
																kkkkk = kkkkk + 3;
															}
															jjjjj = jjjjj + 1;
														}
														iiiii = iiiii + 2;
													}
													kkkk = kkkk + 2;
												}
												jjjj = jjjj + 2;
											}
											iiii = iiii + 1;
										}
										kkk = kkk + 1;
									}
									jjj = jjj + 1;
								}
								iii = iii + 1;
							}
							kk = kk + 1;
						}
						jj = jj + 1;
					}
					ii = ii + 1;
				}
				k  = k  + 1;
			}
			j = j + 1;
		}
		i = i + 1;
	}

	return a;
}
