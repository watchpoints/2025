int k;
const int n = 10;
int main () {
	int i = 0;
	k = 1;
	while (i <= n - 1) {
		i = i + 1;
		k + 1;
		k = k + k;
	}
	putint(k);
	return k;
}
