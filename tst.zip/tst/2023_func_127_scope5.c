int main(){
int a = 0, sum = 0;
a = a + -2;
sum = sum + a;
{
int a = 2;
a = a + 1;
sum = sum + a;
{
int a = 3;
a = a + 2;
sum = sum + a;
{
int a = 2;
a = a + -3;
sum = sum + a;
{
int a = 2;
a = a + -2;
sum = sum + a;
{
int a = 1;
a = a + 2;
sum = sum + a;
{
int a = 1;
a = a + 0;
sum = sum + a;
{
int a = 1;
a = a + 3;
sum = sum + a;
{
int a = 1;
a = a + 2;
sum = sum + a;
{
int a = 1;
a = a + -1;
sum = sum + a;
{
int a = 2;
a = a + 1;
sum = sum + a;
{
int a = 0;
a = a + 1;
sum = sum + a;
{
int a = 4;
a = a + 1;
sum = sum + a;
{
int a = 3;
a = a + -5;
sum = sum + a;
{
int a = 3;
a = a + 0;
sum = sum + a;
{
int a = 3;
a = a + -5;
sum = sum + a;
{
int a = 0;
a = a + 2;
sum = sum + a;
{
int a = 1;
a = a + -5;
sum = sum + a;
{
int a = 4;
a = a + 4;
sum = sum + a;
{
int a = 3;
a = a + -1;
sum = sum + a;
{
int a = 4;
a = a + 4;
sum = sum + a;
{
int a = 1;
a = a + 0;
sum = sum + a;
{
int a = 1;
a = a + -1;
sum = sum + a;
{
int a = 0;
a = a + -1;
sum = sum + a;
{
int a = 1;
a = a + 4;
sum = sum + a;
{
int a = 4;
a = a + 4;
sum = sum + a;
{
int a = 0;
a = a + -4;
sum = sum + a;
{
int a = 2;
a = a + 4;
sum = sum + a;
{
int a = 4;
a = a + -2;
sum = sum + a;
{
int a = 0;
a = a + 4;
sum = sum + a;
{
int a = 3;
a = a + -5;
sum = sum + a;
{
int a = 0;
a = a + -5;
sum = sum + a;
{
int a = 4;
a = a + 1;
sum = sum + a;
{
int a = 1;
a = a + 0;
sum = sum + a;
{
int a = 2;
a = a + -1;
sum = sum + a;
{
int a = 4;
a = a + -4;
sum = sum + a;
{
int a = 0;
a = a + -4;
sum = sum + a;
{
int a = 4;
a = a + -3;
sum = sum + a;
{
int a = 0;
a = a + 1;
sum = sum + a;
{
int a = 1;
a = a + 4;
sum = sum + a;
{
int a = 0;
a = a + 2;
sum = sum + a;
{
int a = 0;
a = a + -5;
sum = sum + a;
{
int a = 0;
a = a + 2;
sum = sum + a;
{
int a = 2;
a = a + -5;
sum = sum + a;
{
int a = 2;
a = a + -1;
sum = sum + a;
{
int a = 4;
a = a + -5;
sum = sum + a;
{
int a = 1;
a = a + -4;
sum = sum + a;
{
int a = 1;
a = a + 0;
sum = sum + a;
{
int a = 0;
a = a + -1;
sum = sum + a;
{
int a = 0;
a = a + 2;
sum = sum + a;
{
int a = 3;
a = a + -5;
sum = sum + a;
{
int a = 1;
a = a + -2;
sum = sum + a;
{
int a = 3;
a = a + -3;
sum = sum + a;
{
int a = 2;
a = a + -5;
sum = sum + a;
{
int a = 3;
a = a + 1;
sum = sum + a;
{
int a = 4;
a = a + 1;
sum = sum + a;
{
int a = 0;
a = a + -4;
sum = sum + a;
{
int a = 1;
a = a + 1;
sum = sum + a;
{
int a = 1;
a = a + -5;
sum = sum + a;
{
int a = 1;
a = a + -2;
sum = sum + a;
{
int a = 4;
a = a + 2;
sum = sum + a;
{
int a = 4;
a = a + -5;
sum = sum + a;
{
int a = 1;
a = a + 2;
sum = sum + a;
{
int a = 2;
a = a + -4;
sum = sum + a;
{
int a = 1;
a = a + 3;
sum = sum + a;
{
int a = 0;
a = a + -4;
sum = sum + a;
{
int a = 0;
a = a + -2;
sum = sum + a;
{
int a = 1;
a = a + 0;
sum = sum + a;
{
int a = 0;
a = a + -1;
sum = sum + a;
{
int a = 0;
a = a + -1;
sum = sum + a;
{
int a = 2;
a = a + 2;
sum = sum + a;
{
int a = 2;
a = a + 2;
sum = sum + a;
{
int a = 3;
a = a + -5;
sum = sum + a;
{
int a = 3;
a = a + 4;
sum = sum + a;
{
int a = 1;
a = a + -4;
sum = sum + a;
{
int a = 3;
a = a + 0;
sum = sum + a;
{
int a = 1;
a = a + 4;
sum = sum + a;
{
int a = 3;
a = a + -3;
sum = sum + a;
{
int a = 3;
a = a + 0;
sum = sum + a;
{
int a = 3;
a = a + 4;
sum = sum + a;
{
int a = 0;
a = a + 0;
sum = sum + a;
{
int a = 2;
a = a + 0;
sum = sum + a;
{
int a = 4;
a = a + 3;
sum = sum + a;
{
int a = 0;
a = a + -1;
sum = sum + a;
{
int a = 4;
a = a + 3;
sum = sum + a;
{
int a = 0;
a = a + 1;
sum = sum + a;
{
int a = 0;
a = a + -3;
sum = sum + a;
{
int a = 1;
a = a + 0;
sum = sum + a;
{
int a = 3;
a = a + 4;
sum = sum + a;
{
int a = 2;
a = a + 1;
sum = sum + a;
{
int a = 3;
a = a + -5;
sum = sum + a;
{
int a = 1;
a = a + -1;
sum = sum + a;
{
int a = 1;
a = a + -4;
sum = sum + a;
{
int a = 1;
a = a + 4;
sum = sum + a;
{
int a = 2;
a = a + -4;
sum = sum + a;
{
int a = 0;
a = a + -1;
sum = sum + a;
{
int a = 1;
a = a + -3;
sum = sum + a;
{
int a = 0;
a = a + 2;
sum = sum + a;
{
int a = 0;
a = a + -3;
sum = sum + a;
{
int a = 4;
a = a + 0;
sum = sum + a;
{
int a = 2;
a = a + -1;
sum = sum + a;
{
int a = 3;
a = a + 4;
sum = sum + a;
{
int a = 4;
a = a + 4;
sum = sum + a;
{
int a = 0;
a = a + -1;
sum = sum + a;
{
int a = 1;
a = a + -3;
sum = sum + a;
{
int a = 0;
a = a + 1;
sum = sum + a;
{
int a = 4;
a = a + -2;
sum = sum + a;
{
int a = 0;
a = a + 2;
sum = sum + a;
{
int a = 2;
a = a + 3;
sum = sum + a;
{
int a = 1;
a = a + -1;
sum = sum + a;
{
int a = 1;
a = a + 1;
sum = sum + a;
{
int a = 0;
a = a + 4;
sum = sum + a;
{
int a = 3;
a = a + -5;
sum = sum + a;
{
int a = 2;
a = a + -5;
sum = sum + a;
{
int a = 0;
a = a + -4;
sum = sum + a;
{
int a = 2;
a = a + 2;
sum = sum + a;
{
int a = 2;
a = a + -2;
sum = sum + a;
{
int a = 4;
a = a + 3;
sum = sum + a;
{
int a = 2;
a = a + -1;
sum = sum + a;
{
int a = 2;
a = a + 0;
sum = sum + a;
{
int a = 3;
a = a + -1;
sum = sum + a;
{
int a = 1;
a = a + -1;
sum = sum + a;
{
int a = 0;
a = a + -2;
sum = sum + a;
{
int a = 1;
a = a + 2;
sum = sum + a;
{
int a = 1;
a = a + 4;
sum = sum + a;
{
int a = 3;
a = a + -1;
sum = sum + a;
{
int a = 2;
a = a + -2;
sum = sum + a;
{
int a = 4;
a = a + 2;
sum = sum + a;
{
int a = 1;
a = a + -2;
sum = sum + a;
{
int a = 2;
a = a + -2;
sum = sum + a;
{
int a = 4;
a = a + 0;
sum = sum + a;
{
int a = 2;
a = a + -2;
sum = sum + a;
{
int a = 0;
a = a + -4;
sum = sum + a;
{
int a = 2;
a = a + -3;
sum = sum + a;
{
int a = 0;
a = a + 1;
sum = sum + a;
{
int a = 0;
a = a + 0;
sum = sum + a;
{
int a = 1;
a = a + -2;
sum = sum + a;
{
int a = 4;
a = a + -2;
sum = sum + a;
{
int a = 2;
a = a + -3;
sum = sum + a;
{
int a = 0;
a = a + -5;
sum = sum + a;
{
int a = 1;
a = a + -2;
sum = sum + a;
{
int a = 0;
a = a + 3;
sum = sum + a;
{
int a = 3;
a = a + -4;
sum = sum + a;
{
int a = 0;
a = a + -1;
sum = sum + a;
{
int a = 4;
a = a + 0;
sum = sum + a;
{
int a = 4;
a = a + 3;
sum = sum + a;
{
int a = 2;
a = a + -3;
sum = sum + a;
{
int a = 3;
a = a + -3;
sum = sum + a;
{
int a = 3;
a = a + 0;
sum = sum + a;
{
int a = 1;
a = a + -4;
sum = sum + a;
{
int a = 2;
a = a + 1;
sum = sum + a;
{
int a = 1;
a = a + 0;
sum = sum + a;
{
int a = 2;
a = a + 3;
sum = sum + a;
{
int a = 3;
a = a + 4;
sum = sum + a;
{
int a = 0;
a = a + 3;
sum = sum + a;
{
int a = 1;
a = a + -1;
sum = sum + a;
{
int a = 3;
a = a + 3;
sum = sum + a;
{
int a = 4;
a = a + -2;
sum = sum + a;
{
int a = 4;
a = a + -5;
sum = sum + a;
{
int a = 0;
a = a + -2;
sum = sum + a;
{
int a = 2;
a = a + 4;
sum = sum + a;
{
int a = 3;
a = a + 4;
sum = sum + a;
{
int a = 1;
a = a + 2;
sum = sum + a;
{
int a = 1;
a = a + 0;
sum = sum + a;
{
int a = 2;
a = a + 2;
sum = sum + a;
{
int a = 3;
a = a + 1;
sum = sum + a;
{
int a = 1;
a = a + -1;
sum = sum + a;
{
int a = 1;
a = a + 3;
sum = sum + a;
{
int a = 4;
a = a + 4;
sum = sum + a;
{
int a = 4;
a = a + 0;
sum = sum + a;
{
int a = 4;
a = a + -5;
sum = sum + a;
{
int a = 1;
a = a + -1;
sum = sum + a;
{
int a = 4;
a = a + 0;
sum = sum + a;
{
int a = 3;
a = a + -5;
sum = sum + a;
{
int a = 2;
a = a + 3;
sum = sum + a;
{
int a = 4;
a = a + -1;
sum = sum + a;
{
int a = 2;
a = a + 4;
sum = sum + a;
{
int a = 3;
a = a + -4;
sum = sum + a;
{
int a = 1;
a = a + 1;
sum = sum + a;
{
int a = 3;
a = a + -4;
sum = sum + a;
{
int a = 1;
a = a + 1;
sum = sum + a;
{
int a = 4;
a = a + -3;
sum = sum + a;
{
int a = 0;
a = a + -2;
sum = sum + a;
{
int a = 2;
a = a + 0;
sum = sum + a;
{
int a = 2;
a = a + -4;
sum = sum + a;
{
int a = 2;
a = a + -1;
sum = sum + a;
{
int a = 3;
a = a + -2;
sum = sum + a;
{
int a = 3;
a = a + -1;
sum = sum + a;
{
int a = 0;
a = a + 3;
sum = sum + a;
{
int a = 0;
a = a + 3;
sum = sum + a;
{
int a = 1;
a = a + -4;
sum = sum + a;
{
int a = 4;
a = a + 1;
sum = sum + a;
{
int a = 2;
a = a + -5;
sum = sum + a;
{
int a = 4;
a = a + -4;
sum = sum + a;
{
int a = 1;
a = a + 2;
sum = sum + a;
{
int a = 2;
a = a + -3;
sum = sum + a;
{
int a = 3;
a = a + -2;
sum = sum + a;
{
int a = 1;
a = a + 0;
sum = sum + a;
{
int a = 1;
a = a + 3;
sum = sum + a;
{
int a = 2;
a = a + -4;
sum = sum + a;
a = a + -4;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 3;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -2;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + 0;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 4;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + -4;
sum = sum + a;
}
a = a + -1;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + -3;
sum = sum + a;
}
a = a + 1;
sum = sum + a;
}
a = a + 2;
sum = sum + a;
}
a = a + -5;
sum = sum + a;
return sum;
}
